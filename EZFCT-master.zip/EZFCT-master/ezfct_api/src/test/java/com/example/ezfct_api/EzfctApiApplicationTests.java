package com.example.ezfct_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EzfctApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
