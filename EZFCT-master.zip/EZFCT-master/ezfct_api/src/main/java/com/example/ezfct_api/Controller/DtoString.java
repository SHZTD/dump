package com.example.ezfct_api.Controller;

public class DtoString {
    String stringData;
    public DtoString(String a){ stringData = a; }
    public String getStringData() {
        return stringData;
    }
    public void setStringData(String a) {
        this.stringData = a;
    }
    public DtoString(){};
}
