package com.example.ezfct_api.Service;

import com.example.ezfct_api.Entity.Login;
import com.example.ezfct_api.Repository.LoginRepository;
import com.example.ezfct_api.Security.AESUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoginService {
    @Autowired
    private LoginRepository loginRepository;

    public boolean checkCredentials(String username, String rawPassword) {
        try {
            String encryptedUsername = AESUtil.encrypt(username);
            Optional<Login> user = loginRepository.findByUsername(encryptedUsername);

            if (user.isPresent()) {
                String decryptedStoredPassword = AESUtil.decrypt(user.get().getPassword());

                return decryptedStoredPassword.equals(rawPassword);

            } else {
                System.out.println("User not found in the database.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}