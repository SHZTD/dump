package com.example.ezfct_api.Playground;
import com.example.ezfct_api.Security.AESUtil;

import java.util.Scanner;

public class UtilTester {
    public static void main(String[] args) throws Exception {
        for(;;) {
            System.out.println("USR Encrypted: ");
            String encryptedUsername = new Scanner(System.in).nextLine();
            System.out.println("PWD Encrypted: ");
            String encryptedPassword = new Scanner(System.in).nextLine();
            if (encryptedUsername.equals("-1") && encryptedPassword.equals("-1")) {
                // no proceses nada y sal del programa
                break;
            } else {
                System.out.println("Username: " + AESUtil.decrypt(encryptedUsername));
                System.out.println("Password: " + AESUtil.decrypt(encryptedPassword));
            }
        }
    }
}