package com.example.ezfct_api.Model;

public enum EstadoPractica {
    PENDIENTE,
    EN_PROGRESO,
    COMPLETADO
}
