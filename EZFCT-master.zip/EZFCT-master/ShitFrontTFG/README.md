# ShitFrontTFG
En JS/TS (se vera) + HTML (nada mas que eso)
Frontend hecho a mano de manera cutre para el TFG 
Si no dispones de una base de datos que respete los campos insert del backend (alumnos y login) para testear,
no funcionara en absoluto el front (te tirara 404)

Si se dispone de la base de datos con sus respetados campos, inicializa la API y que el JPA pueda atacar la BD.
Si la API y la BD estan levantadas, asegurate de respetar tus puertos y IP para hacer requests a la API SpringBoot.

Unicamente para testear los endpoints de manera WEB, no tiene mas misterio.
